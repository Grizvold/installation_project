#!/bin/sh

#creating runnable script on linux
chmod +x ubuntu_program_installation_script.sh

#visual studio code extensions script
chmod +x visual_studio_code_extensions.sh

#atom extensions script
chmod +x atom_extenstions.sh

#./<name of running script> <your ubuntu password> <GIT_NAME> <GIT_EMAIL>
./ubuntu_program_installation_script.sh ct,h kvmkhj "ruslan.gorbaty" "ruslan105@gmail.com"
./visual_studio_code_extensions.sh
./atom_extenstions.sh
